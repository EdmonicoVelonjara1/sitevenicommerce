document.addEventListener("DOMContentLoaded", function() {
    var layout = 1;
    fetch('products1.json')
    .then(response => response.json())
    .then(data => {
        const productContainer = document.getElementById('productContainer');
        data.products.forEach(product => {
            
            const figure = document.createElement('div');
            if(layout === -1){
                figure.classList.remove('figure');
                figure.classList.add('figure1');
                console.log(layout);
            }

            else{
                console.log(layout);
                figure.classList.remove('figure1');
                figure.classList.add('figure');
            }
            const img = document.createElement('img');
            img.src = product.image;
            img.alt = product.name;

            const figcaption = document.createElement('figcaption');
            const a = document.createElement('a');
            a.href = product.link;

            const brand = document.createElement('p');
            brand.innerHTML = `<b>${product.brand}</b>`;

            const productName = document.createElement('p');
            productName.textContent = product.name;

            a.appendChild(brand);
            a.appendChild(productName);
            figcaption.appendChild(a);

            const underCaptionLink = document.createElement('div');
            underCaptionLink.classList.add('under-caption-link');
            const productDescription = document.createElement('a');
            productDescription.href = product.link;
            productDescription.textContent = product.description;
            underCaptionLink.appendChild(productDescription);

            const deliveryType = document.createElement('p');
            deliveryType.classList.add('delivery-type');
            deliveryType.textContent = 'Livraison gratuit'; 

            const price = document.createElement('div');
            price.classList.add('price');
            price.textContent = product.price; // Affichage du prix

            const priceBox = document.createElement('div');
            priceBox.classList.add('priceBox');
            priceBox.appendChild(deliveryType); 
            priceBox.appendChild(price); 


            const buyBtn = document.createElement('div');
            buyBtn.classList.add('buy-btn');
            const buyButton = document.createElement('button');
            buyButton.classList.add('buy');
            buyButton.type = 'button';
            buyButton.textContent = 'J\'achete';
            buyBtn.appendChild(buyButton);

            figure.appendChild(img);
            figure.appendChild(figcaption);
            figure.appendChild(underCaptionLink);
            figure.appendChild(priceBox);
            figure.appendChild(buyBtn);
            productContainer.appendChild(figure);
        });
    });
});