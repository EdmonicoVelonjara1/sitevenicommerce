document.addEventListener('DOMContentLoaded', () => {
    const down_price = document.querySelector('.down-price');
    const down_mark = document.querySelector('.down-mark');
    const down_rchour = document.querySelector('.down-rchour');
    const down_rctype = document.querySelector('.down-rctype');
    const price = document.querySelector('.price');
    const mark = document.querySelector('.mark');
    const buy = document.querySelector('.buy');
    const rchour = document.querySelector('.recharge-hour');
    const rctype = document.querySelector('.recharge-type');
    const filterBtn = document.querySelector('.filter-btn');

    let filterVal = 1;

    filterBtn.addEventListener('click', () => {
        filterVal = - filterVal;
        if(filterVal === -1){
            document.querySelector('.shop-info').style.display = "none";
            document.querySelector('.filter-type').textContent = "Afficher les filtres";
        }
        else{
            document.querySelector('.shop-info').style.display = "flex";
            document.querySelector('.filter-type').textContent = "Masquer les filtres";
        }
    });
    
    price.addEventListener('toggle',() =>{
        if (price.hasAttribute('open')) {
            down_price.classList.add("down-rotate");
        } else {
            down_price.classList.remove("down-rotate");
        }
    });

    mark.addEventListener('toggle',() =>{
        if (mark.hasAttribute('open')) {
            down_mark.classList.add("down-rotate");
        } else {
            down_mark.classList.remove("down-rotate");
        }
    });

    rchour.addEventListener('toggle',() =>{
        if (rchour.hasAttribute('open')) {
            down_rchour.classList.add("down-rotate");
        } else {
            down_rchour.classList.remove("down-rotate");
        }
    });

    rctype.addEventListener('toggle',() =>{
        if (rctype.hasAttribute('open')) {
            down_rctype.classList.add("down-rotate");
        } else {
            down_rctype.classList.remove("down-rotate");
        }
    });

    const slides = document.querySelector('.slides');
    const slide = document.querySelectorAll('.slide');
    const prev = document.querySelector('.prev');
    const next = document.querySelector('.next');
    let currentIndex = 0;


    function showSlide(index) {
        if (index >= slide.length) {
            currentIndex = 0;
        } else if (index < 0) {
            currentIndex = slide.length - 1;
        } else {
            currentIndex = index;
        }

        slides.style.transform = `translateX(-${currentIndex * 100}%)`;
    }

    prev.addEventListener('click', () => {
        showSlide(currentIndex - 1);
    });

    next.addEventListener('click', () => {
        showSlide(currentIndex + 1);
    });

    showSlide(currentIndex);
});

var panier = [];
var produits = [];


document.addEventListener('DOMContentLoaded', (event) => {
    fetch('products1.json')
    .then(response => response.json())
    .then(data => {
        data.products.forEach(prod => {
            produits.push({
                "vendeur": "Techstore",
                "name": prod.name,
                "image": prod.image,
                "price": parseFloat(prod.price),
                "link": prod.link,
                "brand": prod.brand,
                "description": prod.description
            });
        });
        generateProduct();
    });
    event.preventDefault();
});

function generateProduct(){    
    const productList = document.getElementById('productContainer');
    productList.innerHTML = '';
    console.log("VVV" + window.screen.width);

    produits.forEach((item, index) => {
        const productHTML = `    
            <div class="figure">
                <figure class="figure-content">
                    <img src="${item.image}" alt="${item.image}">
                    <figcaption><a href="">
                        <p><b>${item.brand}</b></p>
                        <p>${item.description}</p>
                    </a></figcaption>
                </figure>
                <div class="under-caption-link">
                    <a href="">
                        ${item.link}
                    </a>
                </div>
                <div class="price_uniter">
                    <p>${item.price}&nbsp;€</p>
                </div>
                <div>
                <div class="buy-btn">
                    <button class="buy" type="button" data-index="${index}">
                        J'achète
                    </button>
                </div>
            </div>
        `;
        productList.innerHTML += productHTML;
    });
    let figureContainer = document.querySelectorAll('.figure');
    let figureContent = document.querySelectorAll('.figure-content');

    document.querySelector('.vertical_layout_main').addEventListener('click',()=>{
        document.getElementById('productContainer').style.display = "flex";
        document.getElementById('productContainer').style.backgroundColor = "red";
        document.getElementById('productContainer').style.flexDirection = "column";

        for(let i = 0; i<figureContainer.length; i++){
            figureContainer[i].classList.add("figure2");
            figureContainer[i].querySelector('.price_uniter').style.width ="max-content";
        }

        for(let i = 0; i< figureContent.length; i++){
            figureContent[i].classList.add("figcontent");
        } 
    });
    
    document.querySelector('.grid_layout_main').addEventListener('click',()=>{
        document.getElementById('productContainer').style.display = "grid";
        
        for(let i = 0; i< figureContainer.length; i++){
            figureContainer[i].classList.remove("figure2");
        }

        for(let i = 0; i< figureContent.length; i++){
            figureContent[i].classList.remove("figcontent");
        }
    });
}

document.getElementById('productContainer').addEventListener('click', (event) => {
    if (event.target && event.target.classList.contains('buy')) {
        const index = event.target.getAttribute('data-index');
        const produit = produits[index];
        
        let link_to_verify = {
            "vendeur": "Techstore",
            "produit": produit.name,
            "image": produit.image,
            "prix": parseFloat(produit.price),
            "quantite": 1,
            "reduction": 0
        }

        if(!objectExist(panier, link_to_verify)){
            panier.push({
                "vendeur": "Techstore",
                "produit": produit.name,
                "image": produit.image,
                "prix": parseFloat(produit.price),
                "quantite": 1,
                "reduction": 0 
            });
        }
        else{
            alert("Déjà dans le panier");
        }
        document.querySelector('.list-product').style.transform = 'translateX(-33%)';
        document.querySelector('.list-1').style.color = "green";

        updatePanier();
    }

    document.getElementById("back").addEventListener('click',()=>{
        document.querySelector('.list-product').style.transform = 'translateX(0%)';
    });
});

document.querySelector('.retour').addEventListener('click',()=>{
    document.querySelector('.list-product').style.transform = 'translateX(0%)';
});

document.getElementById("basket_btn").addEventListener('click',()=>{
    document.querySelector('.list-product').style.transform = 'translateX(-33%)';
    document.querySelector('.list-1').style.color = "green";
});

document.querySelector('.pass_commande').addEventListener('click', () => {
    document.querySelector('.list-product').style.transform = 'translateX(-65%)';
    document.querySelector('.list-2').style.color = "green";

});
document.querySelector('.retour1').addEventListener('click', () => {
    document.querySelector('.list-product').style.transform = 'translateX(-33%)';
    document.querySelector('.list-2').style.color = "white";

});

document.querySelector('.connexion').addEventListener('click', () => {
    document.querySelector('.list-product').style.transform = 'translateX(-90%)';
    document.querySelector('.list-3').style.color = "green";
});
document.querySelector('.retour2').addEventListener('click', () => {
    document.querySelector('.list-product').style.transform = 'translateX(-65%)';
    document.querySelector('.list-3').style.color = "white";
    document.querySelector('.list-2').style.color = "green";

});
document.querySelector('.inscription').addEventListener('click', () => {
    document.querySelector('.list-product').style.transform = 'translateX(-90%)';
    document.querySelector('.list-3').style.color = "green";
});

function fileringPrice(){
    const range1 = document.querySelector('.renge1');
    const range2 = document.querySelector('.renge2');
    const range3 = document.querySelector('.renge3');
}

function objectExist(array, obj){
    return array.some(item => item.image === obj.image);
}

function updatePanier() {
    const articleList = document.getElementById('article-list');
    const articleCount = document.getElementById('article-count');
    const basketBtnBefore = document.querySelector('.basket_btn_before');

    let subTotal = 0;
    articleList.innerHTML = '';
    panier.forEach((item, index) => {
        const totalItemPrice = item.prix * item.quantite;
        subTotal += totalItemPrice;
        
        let articleHTML = `
            <div class="list-article">
                <div class="prod_source">
                    <p>Vendu(s) et expédié(s) par <b>${item.vendeur}</b></p>
                </div> 
                <figure class="prod_on_basket">
                    <img src="${item.image}" alt="${item.produit}" width="150">
                    <figcaption>
                        <div class="info-prod">
                            <p>
                                <a href="">
                                    <b>${item.produit}</b>
                                </a>
                            </p>
                            <form>
                                <select name="number" id="number-${index}" onchange="updateQuantite(${index}, this.value)">
                                    ${[...Array(10).keys()].map(i => `<option value="${i+1}" ${i+1 === item.quantite ? 'selected' : ''}>${i+1}</option>`).join('')}
                                </select>
                            </form>
                            <p class="link_whishlist"><a href="">Déplacer vers ma wishlist</a></p>
                        </div>
                        <div class="reduction">
                            <p class="reduction_quantity">-${item.reduction}%</p>
                        </div>
                        <div class="price-reduction">
                            <button type="button" class="delete_to_basket" onclick="removeItem(${index})">
                                <p>X</p>
                            </button>
                            <div class="promo_price">
                                <p class="sub_price">
                                    <s>${(item.prix / (1 - item.reduction / 100)).toFixed(2)} €</s>
                                </p>
                                <p class="real_price">
                                    <b>${totalItemPrice.toFixed(2)} €</b>
                                </p>
                            </div>
                        </div>
                    </figcaption>
                </figure>
            </div>
        `;
    
    articleList.innerHTML += articleHTML;
    });
    document.getElementById('sub-total').innerText = subTotal.toFixed(2) + ' €';
    document.getElementById('total-price').innerText = subTotal.toFixed(2) + '€';
    if(panier.length === 0){
        articleCount.innerHTML = `<div class="empty_basket"><p>Votre panier est vide !</p></div>`;
        document.querySelector('.shop_info').style.display = "none";
    }
    else{

        document.querySelector('.shop_info').style.display = "flex";
        articleCount.innerText = `Vous avez ${panier.length} article(s) dans votre panier`;
    }
    basketBtnBefore.innerText = `${panier.length}`;
  
}

function updateQuantite(index, quantite) {
    panier[index].quantite = parseInt(quantite);
    updatePanier();
}

function removeItem(index) {
    panier.splice(index, 1);
    updatePanier();
}

updatePanier();